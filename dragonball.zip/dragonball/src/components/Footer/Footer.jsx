import { Box } from "@mui/material"
export default function Footer(){
    return (
        <Box sx={{
            height:"200px",
            backgroundColor:"orange",
            }}>
            
        </Box>
    )
}